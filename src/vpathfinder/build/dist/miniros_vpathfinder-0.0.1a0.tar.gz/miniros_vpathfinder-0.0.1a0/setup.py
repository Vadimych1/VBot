from setuptools import setup

setup(
    name='miniros_vpathfinder',
    version='0.0.1a',
    description='miniros package',
    license='MIT',
    packages=['miniros_vpathfinder', 'miniros_vpathfinder.source'],
    keywords=[],
)
