from setuptools import setup

setup(
    name='miniros_vmain',
    version='0.0.1a',
    description='miniros package',
    license='MIT',
    packages=['miniros_vmain', 'miniros_vmain.source'],
    keywords=[],
)
