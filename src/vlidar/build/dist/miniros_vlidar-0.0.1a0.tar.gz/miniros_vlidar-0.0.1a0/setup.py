from setuptools import setup

setup(
    name='miniros_vlidar',
    version='0.0.1a',
    description='miniros package',
    license='MIT',
    packages=['miniros_vlidar', 'miniros_vlidar.source'],
    keywords=[],
)
