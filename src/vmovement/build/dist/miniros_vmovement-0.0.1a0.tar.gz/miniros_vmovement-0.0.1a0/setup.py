from setuptools import setup

setup(
    name='miniros_vmovement',
    version='0.0.1a',
    description='miniros package',
    license='MIT',
    packages=['miniros_vmovement', 'miniros_vmovement.source'],
    keywords=[],
)
