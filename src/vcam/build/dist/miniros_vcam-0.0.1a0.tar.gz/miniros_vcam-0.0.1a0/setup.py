from setuptools import setup

setup(
    name='miniros_vcam',
    version='0.0.1a',
    description='miniros package',
    license='MIT',
    packages=['miniros_vcam', 'miniros_vcam.source'],
    keywords=[],
)
