from setuptools import setup

setup(
    name='miniros_vslam',
    version='0.0.1a',
    description='miniros package',
    license='MIT',
    packages=['miniros_vslam', 'miniros_vslam.source'],
    keywords=[],
)
